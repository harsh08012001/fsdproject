export const brandsItem1 = [
    {name: "Dharmawaram", url: "#"},
    {name: "Pochampalli", url: "#"},
    {name: "Uppada", url: "#"},
    {name: "Banarasi silk", url: "#"},
    {name: "kanchipuram", url: "#"},
    {name: "Pashmina ", url: "#"}
]

export const brandsItem2 = [
    {name: "Gucci", url: "#"},
    {name: "Givenchy", url: "#"},
    {name: "Creed", url: "#"},
    {name: "Jean Paul Gaultier", url: "#"},
    {name: "Paco Rabanne", url: "#"},
    {name: "Giorgio Armani", url: "#"}
]

export const brandsItem3 = [
    {name: "Bvlgari", url: "#"},
    {name: "Calvin Klein", url: "#"},
    {name: "Hermes", url: "#"},
    {name: "Hugo Boss", url: "#"},
    {name: "Lancome", url: "#"},
    {name: "Burberry", url: "#"}
]
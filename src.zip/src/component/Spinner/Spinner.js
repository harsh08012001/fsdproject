import React from 'react';
import "./Spiner.css";

function Spinner(props) {
    return (
        <div className="loadingio-spinner-ellipsis-aeb8fucc4h">
            <div className="ldio-skmr27zgsyi">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>
    );
}

export default Spinner;



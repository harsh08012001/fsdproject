const perfumer = [
    {"name": "Jhakas"},
    {"name": "Afda"},
    {"name": "Hasta Bangla"},
    {"name": "Chaturango"},
    {"name": "Craft Maestro"},
    {"name": "Samanvay"},
    {"name": "Expo Bazaar"},
    {"name": "Rudra Designs"},
    {"name": "Shree Handloom"},
    {"name": "Ramraj"},
    {"name": "Givency"},
    {"name": "Sabyasachi"},
    {"name": "Jaypore"},
    {"name": "Uppada"},
    {"name": "Upasana"},
    {"name": "Dharmavaram"},
    {"name": "Kalamanmdir"},
    {"name": "Textile Tales"},
    {"name": "Weave Craft"},
    {"name": "Thread Works"},
    {"name": "Kanchipuram"},
    {"name": "Gadwal"},
    {"name": "Pochampalli"},
    {"name": "Kalamkari"},
]

const gender = [
    {"name": "male", "label": "для женщин"},
    {"name": "female", "label": "для мужчин"},
]

const price = [
    {"id": 1, "name": "any", "array": []},
    {"id": 2, "name": "1000 - 2000 ", "array": [1000, 2000]},
    {"id": 3, "name": "2000 - 4000 ", "array": [2000, 4000]},
    {"id": 4, "name": "4000 - 9000 ", "array": [4000, 9000]},
    {"id": 5, "name": "9000 - 17500+ ", "array": [9000, 25000]}
]

export {perfumer, gender, price};
export const IMG_URL = "http://localhost:8080/img/";
export const API_BASE_URL = "http://localhost:8080/api/v1/rest";